import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

/*
brief: Starting point of the flutter app

parameters:
(in) List<String> args (command-line arguments, unused here)
(out) void (runs the app)
*/
void main() 
{
  runApp(const MyApp());
}

/*
brief: Sets up the app's theme and home screen, manages theme state.

parameters:
(in) BuildContext context (context for building the widget tree)
(out) Widget (the MaterialApp)
*/
class MyApp extends StatefulWidget 
{
  const MyApp({super.key});

  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> 
{
  ThemeMode _themeMode = ThemeMode.system;

  @override
  void initState() 
  {
    super.initState();
    _loadTheme();
  }

  /*
  brief: Loads the saved theme from SharedPreferences.

  parameters:
  (out) Future<void> (asynchronous function to load theme)
  */
  Future<void> _loadTheme() async 
  {
    final prefs = await SharedPreferences.getInstance();
    final theme = prefs.getString('theme') ?? 'System';

    // Change theme state for stateless widget
    setState(() 
    {
      // theme light mode by default, otherwise changes Theme based on local database stored value
      _themeMode = theme == 'Light' ? ThemeMode.light : theme == 'Dark' ? ThemeMode.dark : ThemeMode.system;
    });
  }

  /*
  brief: Updates the theme and saves it to SharedPreferences.

  parameters:
  (in) String theme (new theme value: 'System', 'Light', or 'Dark')
  (out) void (updates the UI and persists the theme)
  */
  void _updateTheme(String theme) async 
  {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('theme', theme);

    setState(() 
    {
      _themeMode = theme == 'Light' ? ThemeMode.light : theme == 'Dark' ? ThemeMode.dark : ThemeMode.system;
    });
  }

  @override
  Widget build(BuildContext context) 
  {
    return MaterialApp(
      title: 'Sugar Tracker',
      theme: ThemeData(primarySwatch: Colors.blue, brightness: Brightness.light),
      darkTheme: ThemeData(primarySwatch: Colors.blue, brightness: Brightness.dark),
      themeMode: _themeMode,
      home: MainScreen(onThemeChanged: _updateTheme),
    );
  }
}

/*
brief: Represents a food item with nutritional information

parameters:
(in) String id (unique identifier for the food)
(in) String name (name of the food)
(in) String brand (brand of the food)
(in) double sugarPer100g (sugar content per 100g)
(in) String imageUrl (URL for the food image)
(in) Map<String, dynamic> nutrients (full nutrient data)
(in) DateTime? date (date when saved, optional)
(out) FoodItem (constructed food item object)
*/
class FoodItem 
{
  final String id;
  final String name;
  final String brand;
  final double sugarPer100g;
  final String imageUrl;
  final Map<String, dynamic> nutrients;
  final DateTime? date;

  FoodItem(
    {
      required this.id,
      required this.name,
      required this.brand,
      required this.sugarPer100g,
      required this.imageUrl,
      required this.nutrients,
      this.date,
    }
  );

  Map<String, dynamic> toJson() => 
  {
        'id': id,
        'name': name,
        'brand': brand,
        'sugarPer100g': sugarPer100g,
        'imageUrl': imageUrl,
        'nutrients': nutrients,
        'date': date?.toIso8601String() ?? DateTime.now().toIso8601String(),
  };

  /* 
  brief: factory constructur: creates a FoodItem from JSON data for local storage purposes

  parameters: Map<String, dynamic> json (JSON data to parse)
  (in) Map<String, dynamic> data (OpenFoodFacts data to parse)
  (out) FoodItem (constructed food item object)
  */ 
  factory FoodItem.fromJson(Map<String, dynamic> json) => 
  FoodItem(
    id: json['id'] ?? 'Unknown',
    name: json['name'] ?? 'Unknown',
    brand: json['brand'] ?? 'Unknown',
    sugarPer100g: (json['sugarPer100g'] is num) ? (json['sugarPer100g'] as num).toDouble() : 0.0,
    imageUrl: json['imageUrl'] ?? '',
    nutrients: json['nutrients'] is Map ? Map<String, dynamic>.from(json['nutrients']) : {},
    date: json['date'] != null ? DateTime.parse(json['date']) : null,
  );

  /*
  brief: factory constructor: creates a FoodItem from OpenFoodFacts data
  
  parameters:
  (in) Map<String, dynamic> data (OpenFoodFacts data to parse)
  (out) FoodItem (constructed food item object)

  */
  factory FoodItem.fromOpenFoodFacts(Map<String, dynamic> data) => 
  FoodItem(
    id: data['code'] ?? 'Unknown',
    name: data['product_name'] ?? 'Unknown',
    brand: data['brands'] ?? 'Unknown',
    sugarPer100g: data['nutriments'] != null && data['nutriments']['sugars_100g'] is num ? (data['nutriments']['sugars_100g'] as num).toDouble() : 0.0,
    imageUrl: data['image_url'] ?? '',
    nutrients: data['nutriments'] ?? {},
    date: null,
  );
}

/*
brief: Handles local storage using SharedPreferences.

parameters:
(in) BuildContext context
(out) LocalStorage
*/
class LocalStorage 
{
  static const String _key = 'saved_foods';

  static Future<List<FoodItem>> getSavedFoods() async 
  {
    final prefs = await SharedPreferences.getInstance();
    final jsonList = prefs.getStringList(_key) ?? [];

    // Decode each JSON string and convert it to a FoodItem object
    return jsonList.map((json) => FoodItem.fromJson(jsonDecode(json))).toList();
  }

  static Future<void> saveFood(FoodItem food) async 
  {
    final prefs = await SharedPreferences.getInstance();
    final savedFoods = await getSavedFoods();
    
    // Remove existing food with same ID if it exists
    savedFoods.removeWhere((item) => item.id == food.id);
    
    savedFoods.add(food);
    final jsonList = savedFoods.map((item) => jsonEncode(item.toJson())).toList();
    await prefs.setStringList(_key, jsonList);
  }

  static Future<void> removeFood(String foodId) async 
  {
    final prefs = await SharedPreferences.getInstance();
    final savedFoods = await getSavedFoods();
    savedFoods.removeWhere((food) => food.id == foodId);
    final jsonList = savedFoods.map((item) => jsonEncode(item.toJson())).toList();
    await prefs.setStringList(_key, jsonList);
  }

  static Future<void> clearFoods() async 
  {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_key);
  }
}

/*
brief: Provides API services to interact with OpenFoodFacts.

parameters:
(in) BuildContext context
(out) OpenFoodFactsAPI (API service)
*/
class OpenFoodFactsAPI
{
  static const String _baseUrl = 'https://world.openfoodfacts.org/api/v2/';

  static Future<List<FoodItem>> searchFood(String query) async 
  {
    try 
    {
      final encodedQuery = query.replaceAll(' ', '%20'); // URL percent encoding for spaces

      // Make a GET request to the OpenFoodFacts API
      final response = await http.get(Uri.parse('$_baseUrl/search?search_terms=$encodedQuery'));
      if (response.statusCode == 200) 
      {
        final data = json.decode(response.body);
        return data['products'] != null ? List<FoodItem>.from(data['products'].map((product) => FoodItem.fromOpenFoodFacts(product))) : [];
      }
      return [];
    } 
    catch (e)
    {
      print('Error fetching food data: $e');
      return [];
    }
  }
}

/*
brief: Main screen with bottom navigation to switch between app sections.

parameters:
(in) BuildContext context (context for building the widget)
(in) Function(String) onThemeChanged (callback to update theme)
(out) Widget (Scaffold with IndexedStack and BottomNavigationBar)
*/
class MainScreen extends StatefulWidget 
{
  final Function(String) onThemeChanged;
  const MainScreen({super.key, required this.onThemeChanged});

  @override
  _MainScreenState createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> 
{
  int _selectedIndex = 0;
  late List<Widget> _screens;
  final GlobalKey<_HomeScreenState> _homeScreenKey = GlobalKey<_HomeScreenState>();
  final GlobalKey<_StoredFoodScreenState> _storedFoodScreenKey = GlobalKey<_StoredFoodScreenState>();

  // brief: Initialises the screens for bottom navigation bar
  @override
  void initState() 
  {
    super.initState();
    _screens = 
    [
      HomeScreen(key: _homeScreenKey),
      AddFoodScreen(onFoodAdded: _refreshScreens),
      StoredFoodScreen(key: _storedFoodScreenKey),
      SettingsScreen(onThemeChanged: widget.onThemeChanged),
    ];
  }

  /*
  brief: Refreshes the home and stored food screens when a food item is added

  parameters:
  (out) void (refreshes screens)
  */
  void _refreshScreens() {
    if (_homeScreenKey.currentState != null) {
      _homeScreenKey.currentState!._loadFoods();
    }
    if (_storedFoodScreenKey.currentState != null) {
      _storedFoodScreenKey.currentState!._loadFoods();
    }
  }

  // brief: Updates the selected index for bottom navigation bar
  void _onItemTapped(int index) => setState(() => _selectedIndex = index);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Sugar Tracker')),
      body: IndexedStack(index: _selectedIndex, children: _screens),
      bottomNavigationBar: BottomNavigationBar(
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.search), label: 'Add Food'),
          BottomNavigationBarItem(icon: Icon(Icons.list), label: 'Stored'),
          BottomNavigationBarItem(icon: Icon(Icons.settings), label: 'Settings'),
        ],
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        selectedItemColor: Colors.blue,
        unselectedItemColor: Colors.grey,
        type: BottomNavigationBarType.fixed,
      ),
    );
  }
}

/*
brief: Home screen displaying saved foods and total sugar intake.

parameters:
(in) BuildContext context (context for building the widget)
(out) Widget (Column with total sugar and list of foods)
*/
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<FoodItem> savedFoods = [];

  @override
  void initState() {
    super.initState();
    _loadFoods();
  }

  Future<void> _loadFoods() async {
    final foods = await LocalStorage.getSavedFoods();
    if (mounted) {
      setState(() => savedFoods = foods);
    }
  }

  @override
  Widget build(BuildContext context) {
    double totalSugar = savedFoods.fold(0.0, (sum, item) => sum + item.sugarPer100g);
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(16.0),
          child: Text(
            'Total Sugar: ${totalSugar.toStringAsFixed(1)}g',
            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
        ),
        Expanded(
          child: savedFoods.isEmpty
              ? const Center(child: Text('No saved foods yet.'))
              : ListView.builder(
                  itemCount: savedFoods.length,
                  itemBuilder: (context, index) => ListTile(
                    title: Text(savedFoods[index].name),
                    subtitle: Text('Sugar: ${savedFoods[index].sugarPer100g}g'),
                  ),
                ),
        ),
      ],
    );
  }
}

/*
brief: Screen to search and add food items.

parameters:
(in) BuildContext context (context for building the widget)
(in) VoidCallback onFoodAdded (callback when food is added)
(out) Widget (Column with search bar and results list)
*/
class AddFoodScreen extends StatefulWidget {
  final VoidCallback onFoodAdded;
  
  const AddFoodScreen({
    super.key,
    required this.onFoodAdded,
  });
  
  @override
  _AddFoodScreenState createState() => _AddFoodScreenState();
}

class _AddFoodScreenState extends State<AddFoodScreen> 
{
  final TextEditingController _searchController = TextEditingController();
  List<FoodItem> searchResults = [];
  bool _isLoading = false;

  Future<void> _searchFood() async 
  {
    final String query = _searchController.text;
    if (query.isEmpty) return;
    
    setState(() => _isLoading = true);
    
    final results = await OpenFoodFactsAPI.searchFood(query);
    
    if (mounted) {
      setState(() {
        searchResults = results;
        _isLoading = false;
      });
    }
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        children: [
          TextField(
            controller: _searchController,
            decoration: InputDecoration(
              labelText: 'Enter a Food Item Name',
              suffixIcon: IconButton(icon: const Icon(Icons.search), onPressed: _searchFood),
              border: const OutlineInputBorder(),
            ),
            onSubmitted: (_) => _searchFood(),
          ),
          const SizedBox(height: 16),
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator())
                : searchResults.isEmpty
                    ? const Center(child: Text('Search for food to see results'))
                    : ListView.builder(
                        itemCount: searchResults.length,
                        itemBuilder: (context, index) => ListTile(
                          title: Text(searchResults[index].name),
                          subtitle: Text('Sugar: ${searchResults[index].sugarPer100g}g per 100g'),
                          onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => FoodDetailsScreen(
                                food: searchResults[index],
                                onFoodAdded: () {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(content: Text('Food added'))
                                  );
                                  widget.onFoodAdded();
                                },
                              ),
                            ),
                          ),
                        ),
                      ),
          ),
        ],
      ),
    );
  }
}

/*
brief: Screen to view and manage stored food items.

parameters:
(in) BuildContext context (context for building the widget)
(out) Widget (ListView with food items and remove buttons)
*/
class StoredFoodScreen extends StatefulWidget {
  const StoredFoodScreen({super.key});
  
  @override
  _StoredFoodScreenState createState() => _StoredFoodScreenState();
}

class _StoredFoodScreenState extends State<StoredFoodScreen> {
  List<FoodItem> savedFoods = [];

  @override
  void initState() {
    super.initState();
    _loadFoods();
  }

  Future<void> _loadFoods() async {
    final foods = await LocalStorage.getSavedFoods();
    if (mounted) {
      setState(() => savedFoods = foods);
    }
  }

  @override
  Widget build(BuildContext context) {
    return savedFoods.isEmpty
        ? const Center(child: Text('No stored foods yet.'))
        : ListView.builder(
            itemCount: savedFoods.length,
            itemBuilder: (context, index) => ListTile(
              title: Text(savedFoods[index].name),
              subtitle: Text('Sugar: ${savedFoods[index].sugarPer100g}g'),
              trailing: IconButton(
                icon: const Icon(Icons.delete),
                onPressed: () async {
                  await LocalStorage.removeFood(savedFoods[index].id);
                  _loadFoods();
                },
              ),
            ),
          );
  }
}

/*
brief: Settings screen with theme selection and clear option.

parameters:
(in) BuildContext context (context for building the widget)
(in) Function(String) onThemeChanged (callback to update theme)
(out) Widget (Column with dropdown and clear button)
*/
class SettingsScreen extends StatefulWidget {
  final Function(String) onThemeChanged;
  const SettingsScreen({super.key, required this.onThemeChanged});

  @override
  _SettingsScreenState createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  String _theme = 'System';

  @override
  void initState() {
    super.initState();
    _loadTheme();
  }

  /*
  brief: Loads the saved theme to initialize the dropdown.

  parameters:
  (out) Future<void> (asynchronous operation to load theme)
  */
  Future<void> _loadTheme() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() => _theme = prefs.getString('theme') ?? 'System');
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Settings', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const SizedBox(height: 16),
          DropdownButton<String>(
            value: _theme,
            onChanged: (String? newValue) {
              if (newValue != null) {
                setState(() => _theme = newValue);
                widget.onThemeChanged(newValue); // Update app theme
              }
            },
            items: <String>['System', 'Light', 'Dark'].map<DropdownMenuItem<String>>((value) => DropdownMenuItem<String>(value: value, child: Text(value))).toList(),
          ),
          const SizedBox(height: 16),
          ElevatedButton(
            onPressed: () {
              showDialog(
                context: context,
                builder: (context) => AlertDialog(
                  title: const Text('Clear Stored Foods'),
                  content: const Text('Are you sure you want to clear all stored foods?'),
                  actions: 
                  [
                    TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
                    TextButton(
                      onPressed: () async {
                        await LocalStorage.clearFoods();
                        Navigator.pop(context);
                        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('All foods cleared')));
                      },
                      child: const Text('Clear'),
                    ),
                  ],
                ),
              );
            },
            child: const Text('Clear Stored Food Items'),
          ),
        ],
      ),
    );
  }
}

/*
brief: Screen to display food details with an option to add.

parameters:
(in) BuildContext context (context for building the widget)
(in) FoodItem food (food item to display)
(in) VoidCallback? onFoodAdded (callback when food is added)
(out) Widget (Scaffold with food details and add button)
*/
class FoodDetailsScreen extends StatelessWidget {
  final FoodItem food;
  final VoidCallback? onFoodAdded;
  
  const FoodDetailsScreen({
    super.key, 
    required this.food, 
    this.onFoodAdded,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Food Details')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(food.name, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text('Brand: ${food.brand}'),
            const SizedBox(height: 16),
            Text('Sugar: ${food.sugarPer100g}g per 100g'),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () async {
                await LocalStorage.saveFood(FoodItem(
                  id: food.id,
                  name: food.name,
                  brand: food.brand,
                  sugarPer100g: food.sugarPer100g,
                  imageUrl: food.imageUrl,
                  nutrients: food.nutrients,
                  date: DateTime.now(),
                ));
                if (onFoodAdded != null) {
                  onFoodAdded!();
                }
                Navigator.pop(context);
              },
              child: const Text('Add to Stored Foods'),
            ),
          ],
        ),
      ),
    );
  }
}