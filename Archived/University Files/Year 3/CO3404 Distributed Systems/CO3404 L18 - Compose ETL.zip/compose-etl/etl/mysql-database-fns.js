// All database functionality is in here and exported. This enables the database type to be changed and
// only this file needs to change if the function names are kep the same. e.g., decide to use mongo instead of mysql

const mysql = require('mysql2/promise') // Needs newer mysql package for the version of container used
const fs = require('fs/promises')       // File system package now has promise built-in on request

let pool  // File scope obj holding the connection pool

// Doesn't actually connect but does initialise some connection objects ready for use
// Much easier to create a database outside - e.g. cli or workbench. Can do it here, connect to mysql without a database
// defined. Issue a create query. Disconnect and create new connection to the new database
function createConPool() {
  const connectionObj = {
    host: process.env.MYSQL_HOST || 'localhost',
    user: process.env.MYSQL_USER || 'admin',
    password: PASSWORD = process.env.MYSQL_PASSWORD || 'admin',
    database: DATABASE = process.env.MYSQL_DATABASE || 'triv',
    port: process.env.MYSQL_PORT || 3306,

    // Add database specific config performance settings 
    waitForConnections: true, // If all connections in use then queue & wait for one to be free rather than returning error
    connectionLimit: 10,      // Max concurrent connections
    queueLimit: 0             // Max queue length. Reject connections if more then this number. 0 means infinite queue
  }
  pool = mysql.createPool(connectionObj)
  console.log(`Created connection pool to database: ${connectionObj.database} using`, connectionObj)
}

// The pool creates connection objects but doesn't make a connection
// If you want to connect to make sure the database is there and to 
// make the user feel better, execute a query on the database
async function isConnected() {
  try {
   // const result = await queryDatabase('SELECT 1') // result is true if DB is up
    const [result] = await queryDatabase('SELECT DATABASE() AS CurrentDatabase') 
    return result.CurrentDatabase // result is a 1 element array with an object so deconstruct
  } catch (err) {
    await pool.end() // Close all pool connections and wait until complete
    throw err
  }
}

async function dropTable(tableName) {
 const sql = `DROP TABLE IF EXISTS ${tableName}`
 await queryDatabase(sql)
}

// Get all data from the table and return to caller. To test the exception stack
// change * to *q to make it fail then trace the exception back to the source
async function getData(table) {
 let sql = `SELECT * FROM ${table}`
 try {
   return await queryDatabase(sql)
 } catch (err) {
   throw err
 }
}


async function createTable(tableName) {
 // Recreate during testing. 
 const sql = 'CREATE TABLE ' + tableName + '(   \
 `id` INT NOT NULL AUTO_INCREMENT,              \
 `question` TEXT NOT NULL,                      \
 `answer` TEXT NOT NULL,                        \
 PRIMARY KEY (`id`),                            \
 UNIQUE INDEX `id_UNIQUE` (`id` ASC) VISIBLE);'

 return await queryDatabase(sql)
}


// Return number of rows in table
async function countRows(tableName) {
  const sql = `SELECT COUNT(*) FROM ${tableName};`
  const [result] = await queryDatabase(sql)
  return result['COUNT(*)'] // One of the few cases where can't use result. as the attribute is a string
}




// Note: this function looks for tabs between Q and A and CR for end of question
// so last question in the data file must end with a CR 
async function etl(tableName, filename) {
  let data = await fs.readFile(filename, "binary") // Uses built-in promise
//  console.log(data)
  data = data.replace(/'/g, "''") // Escape all apostropes
  let question = ''
  let answer = ''
  let isQuestion = true // Determine if reading a q or a
  let qArr = []         // Build up the extracted questions
  let ansArr = []       // Build up the extracted answers
  const TAB = '\t'  // Tab char delimiter for question
  const CR = '\r'  // Carriage return delimiter for answer
  const LF = '\n'   // Line Feed

  // Extract all questions and answers into arrays. These are tab and oel delimited
  for (let i = 0; i < data.length; i++) {
    if (isQuestion) {
      if (data[i] != TAB) {
        question += data[i]
      } else {
        isQuestion = false
        qArr.push(question)
        question = ''
      }
    } else {
      if (data[i] != CR && data[i] != LF) {
        answer += data[i]
      } else {
        // No need to jump CR as loop will do that
        if (data[i + 1] == LF) i++ // But if next is LF, i.e. Windows, need to force a jump
        isQuestion = true
        ansArr.push(answer)
        answer = ''
      }
    }
  }

  let sql = `insert into ${tableName} (question, answer) values`
  let i = 0
  while (i < qArr.length - 1) {               // Treat last one differently
    sql += `('${qArr[i]}','${ansArr[i]}'),`
    i++
  }
  sql += `('${qArr[i]}','${ansArr[i]}');` // Don't want a comma on this one

  const result = await queryDatabase(sql)
  return result
}



// General purpose database query function. Pass in the query and any optional params
// This is a private function and not exported
async function queryDatabase(query, params = []) {
 let connection
 try {
   connection = await pool.getConnection() // Get a connection from the pool. Wait for it to return
   if (connection) console.log("Connection made to database")
   const [rows] = await connection.execute(query, params) // Execute the query. Deconstruct array to just get the rows
   return rows
 } catch (err) {
  console.log(`Connection failed - will throw error ${err}`)
   throw err
 } finally {
   if (connection) connection.release() // Release the connection back to the pool regardless of success or failure
 }
}


// This could be used to create database but as we need to connect to something
// we would need to connect to an unnamed database, call this to create one
// then close the pool to the unnamed database and create a new one for the
// newly named database. Or, to keep it simple, create the database using
// sql cli or workbench
async function createDatabase(dbName) {
 await queryDatabase('CREATE DATABASE IF NOT EXISTS `stuff`')
 await pool.end
 //await queryDatabase('USE `stuff`')
}


createConPool() // Create the connections pool

// Export functions that avoid the user needing to know the type of database
module.exports = {
 getData,
 countRows,
 createTable,
 etl,
 dropTable,
 isConnected
}