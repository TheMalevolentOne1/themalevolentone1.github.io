// This file is the main app server and router. If there were more routes the routing code would be moved out of here
// The database code has been decoupled from this file and is in its own file(s) which are conditionally required
// DB_TYPE is an env var that determines which database file is used with the application
// The file uses default values in here for development but uses .env when containerised
// See the compose.yaml file for detail on how containers are created conditionally based on the database type
const express = require('express')
const app = express()
const path = require('path')

// process.env is native to node - not the dotenv packege. dotenv is used to read a .env file and write the values to the envronment
const PORT = process.env.ETL_PORT || 3001
const STAGING_AREA = process.env.STAGING_AREA || '../data'
const dataPath = path.resolve(__dirname, STAGING_AREA)

// Create constants and defaults when running in vscode
// Determine which database handling file is included
const DB_TYPE = process.env.DB_TYPE || 'mysql'
const MYSQL_CODE = process.env.MYSQL_CODE || './mysql-database-fns'
const MONGO_CODE = process.env.MONGO_CODE || './mongo-database-fns'

switch (DB_TYPE) {
  case 'mysql': db = require(`${MYSQL_CODE}`); break
  case 'mongo': db = require(`${MONGO_CODE}`); break

  default:
    throw new Error("No Database technology provided in DB_TYPE environment variable");

}

console.log(`DB_TYPE is ${DB_TYPE}`)

// Used to just check the app is alive
app.get('/', async (req, res) => {
  res.send('ETL Service is responding')
})

app.get('/host', (req, res) => {
  res.send(`ETL served by container / pod: ${process.env.HOSTNAME}`)
})


// This endpoint takes data filename and table to load into
app.get('/etl/:table/:filename', async (req, res) => {
  try {
    console.log(`In get etl with table name: ${req.params.table} and file: ${dataPath}/${req.params.filename}`)
    await db.dropTable(req.params.table)   // Start from scratch for the demo
    console.log(`Sucessfully dropped table: ${req.params.table}`)
    await db.createTable(req.params.table)
    console.log(`Sucessfully created table: ${req.params.table}`)
    await db.etl(req.params.table, dataPath + '/' + req.params.filename)
    console.log(`Sucessfully completed ETL`)
    let result = await db.countRows(req.params.table)
    console.log(`Counted ${result} rows modified`)
    res.send(`Added ${result} rows.`)
  } catch (err) {
    console.log('Failed with error:', err)
    res.send(`Failed: ${err.message}`)
  }
})

// Return all data from the table. 
app.get('/data/:table', async (req, res) => {
  try {
    response = await db.getData(req.params.table)
    res.send(response)
  } catch (err) {
    res.status(500).send(err) // Server error
  }
})

app.listen(PORT, () => console.log(`ETL application listening on port ${PORT}`))

async function checkConnected() {
  try {
    const dbName = await db.isConnected()
    console.log(`Connected to ${DB_TYPE}: ${dbName} database`)
  } catch (err) {
    console.log(`Failed to connected to database. Error: ${err}. Application will terminate.`)
    process.exit(1)  // Kill the app as connection failed
  }
}

checkConnected()



