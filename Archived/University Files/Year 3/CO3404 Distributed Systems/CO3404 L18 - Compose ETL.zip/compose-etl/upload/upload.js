// endpoint: /upload saves data posted into this app into a file on the server 
// in a folder called data with the same filename
// This uses multer package to handle multipart post

const express = require('express')
const app = express()
const path = require('path')      // Form reliable absolute paths from parts
const multer = require('multer')  // Handle multi-part upload. i.e. files and data
const axios = require('axios')

app.use(express.static(__dirname, {index: 'upload.html'})) // __dirname is relative to this applicaiton
app.use(express.urlencoded({ extended: false })) // use this for standard text post from a form using application/x-www-form-urlencoded
app.use(express.json()) // Parse json data into body attributes. Not used in this app - here for demo only using thunder client

// Note, this is initialised by docker compose so if not using containers, need a fallback port as in ||
const ETL_PORT = process.env.ETL_PORT || 3001 // Need to make sure this is in the caller environment vars in compose
const ETL_HOST = process.env.ETL_CONT_SERVICE || 'localhost'
const PORT = process.env.UPLOAD_PORT || 3000 // Set as env var in docker compose to keep them all in one place
const STAGING_FOLDER = process.env.STAGING_AREA || '../data' // Get the folder name to avoid fixed file paths

const dataPath = path.resolve(__dirname, STAGING_FOLDER )
console.log(`resolved to data path: ${dataPath}`)

// Quick and dirty - create an upload dir if there isn't one as multer needs one
const fs = require('fs')

// Create the staging area when app starts if not exist
console.log(`Staging: ${dataPath}`)
if (!fs.existsSync(dataPath)) {
  fs.mkdirSync(dataPath);
}

// Set up storage engine for uploaded files - a folder needs to already exist hence above
// This is decoupled from the upload as storage could be memory, local disk or somewhere else
// such as Amazon S3 or Azure Blob
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, dataPath)
  },
  filename: (req, file, cb) => {
    cb(null, file.originalname)
  }
})


// Create the multer instance called upload, and associate with the allocated storage
const upload = multer({ storage: storage })

app.get('/host', (req, res) => {
  res.send(`Upload served by container / pod: ${process.env.HOSTNAME}`)
})
 


// Note: 'file' here is the name field value from the form: <input type="file" name="file" required>
// upload is the multer instance and the method .single is registered on the middleware stack before
// the usual callback (req, res). upload will copy the received file data to the storage area. It determines
// the location of the storage area by calling the destination and filename callbacks. Once complete
// it creates a file attribute and adds it to the req objec then calls next() to execute the main
// path callback
app.post('/upload', upload.single('file'), (req, res) => {
  // req has file and other multipart added to it by multer
  res.send(`Successful upload: ${req.file.destination}/${req.file.filename}`)
})


// Table name and source filename posted to endpoint. Axios calls ETL to read the uploaded data
// transform it and load it into the database
app.post('/load-table', async (req, res) => {
  console.log(`In load path`)
  try {
    const response = await axios.get(`http://${ETL_HOST}:${ETL_PORT}/etl/${req.body.table}/${req.body.filename}`)
    res.send(response.data)
  } catch (err) {
    res.json(err.cause.errors)
  }
})

app.listen(PORT, () => {
  console.log(`Upload is running on port ${PORT}`)
})