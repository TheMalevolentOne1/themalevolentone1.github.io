
Only using this demo now for K8S demo
Check it works with containers first as the images will be needed

Local containers
----------------
Worth logging out of docker hub if pull policy is set to always. Would need to log back in for a push
docker compose up -d --build
localhost:4000
Choose a file e.g. quiz.txt
Mine are in C:\Users\tonyn\OneDrive - UCLan\CO3404\Demos\all_scripts\Data files
Upload data
Back
enter a table name - this will be dropped if it exists and a new one created
choose the file to ETL - i.e. one that has been uploaded to the docker volume - e.g. quiz.txt
Execute. Number of rows created should be returned
New tab: localhost:4002 for the caller app to read a table from the database
Choose table to read | read table
docker compose down -v  # we don't need the containers or volume anymore

Kubernetes
----------
If that works, we can use the images in K8S
Enable k8s in docker 
Kubernetes | create cluster | Kubeadm | this is the kubernetes installer so have a brew
On completion, at the terminal try kubectl version

move to k8s dir
cubectl apply -f .
localhost:30000





If interested
Local vscode
------------
If using vscode, default in etl needs to be set to mysql or mongo
This will work as mysql and mongo are installed on the system
If using containers, set it in .env

Use vscode launch config to start all three in debugger
Run upload with localhost:3000
Caller is at 3002

For local containers:
Logout of docker hub to avoid always pull policy pulling an old version from my repo
For default mysql: Build containers locally set .env to mysql
   docker compose up -d --build
Set database type in the .env file and also need to pull mongo if using by overriding the db in compose with:
   docker compose -f compose.yaml -f mongo.yaml up -d --build


For cloud
There is a terraform build script for this architecture. /docker/compose-etl-infra just use terraform apply -auto-approve
Upload is 4000 and caller 4002
Setting the database type in the terraform tfvars file overrides the .env setting due to env order of precedence

