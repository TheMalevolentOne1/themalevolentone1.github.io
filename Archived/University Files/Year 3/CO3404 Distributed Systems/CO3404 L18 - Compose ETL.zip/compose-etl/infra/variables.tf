variable "db_type" {
  type    = string
  default = "mysql"
}

variable "compose_path" {
  type = string
}

variable "docker_script_dir" {
  type = string
}

# Added this as not all onedrives are on drive C so config from .tfvars
variable "one_drive_dir" {
  type = string
}

variable "docker_script_name" {
  type = string
}

variable "pub_key" {
  type        = string
  description = <<EOF
    You can generate your own keys and add the public key here in raw or point to a file
    Or use the one created in Azure. It keeps a copy of the public key that you can ask for
    the ssh public key is copied to ~/.ssh/authorized_keys on the vm for use in ssh
  EOF
}
