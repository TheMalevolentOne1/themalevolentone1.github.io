# Settings for ETL Demos



db_type = "mysql" # mongo or mysql
pub_key = "c:/key/az.pub"

compose_path = "../"
#docker_script_dir = "D:\\oneDriveUclan\\OneDrive - University of Lancashire\\CO3404\\Demos\\all_scripts"
docker_script_dir  = "CO3404/Demos/all_scripts" # echo $Env:OneDrive to find out where it is 
docker_script_name = "docker-az-tf.sh"
one_drive_dir      = "C:\\Users\\tonyn\\OneDrive - UCLan" # To find the dir use: echo $Env:OneDrive
