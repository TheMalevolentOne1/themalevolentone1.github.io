
# In the locals, change the db_type to mysql or mongo to build and deploy one or the other

# More difficult with azure. AWS simply need the region
provider "azurerm" {
  # subscription_id available from console or: az account show --query id --output tsv
  subscription_id = "5645f4b2-db38-4326-b7a6-98d374ebdd9c"
  features {}
}

locals {
  dest_dir = "/home/tony"
}

resource "azurerm_resource_group" "etl" {
  name     = "etl-rg"  # RG name seen in the portal
  location = "uksouth" # Azure region. AWS uses regions. Azure uses locations. Azure has more locations than AWS
}


resource "azurerm_virtual_network" "etl" {
  name                = "etl-vnet"                          # Value seen in portal
  address_space       = ["10.0.0.0/16"]                     # Could use /8 but /16 is far more than needed anyway. /16 gives us 2^16 IP addresses
  location            = azurerm_resource_group.etl.location # Don't know why it can't work out the location from the RG name
  resource_group_name = azurerm_resource_group.etl.name     # Specify resource group. Important it's same for vms to communicate
}

resource "azurerm_subnet" "etl" {
  name                 = "etl-subnet"                     # Subnet within the Vnet. 
  resource_group_name  = azurerm_resource_group.etl.name  # Which resurce group. AWS doesn't use RGs
  virtual_network_name = azurerm_virtual_network.etl.name # Link VM subnet to Vnet. Another Vm needs to be different. e.g. 10.0.3.0/24 or however many IPs you want
  address_prefixes     = ["10.0.2.0/24"]                  # /24 gives us 2^8 or 256 IPs. Minus 3 used by Azure and - another for broadcast
}

resource "azurerm_public_ip" "etl-ip" {
  name                = "etl-pip"
  location            = azurerm_resource_group.etl.location # Which region is resource group as we can span regions
  resource_group_name = azurerm_resource_group.etl.name     # RG name this IP belongs to
  #allocation_method   = "Dynamic"   # Dynamic is about $0.004/hour and static is $0.005/hour
  allocation_method = "Static"   # These cost more but stay in place after a restart
  sku               = "Standard" # Ensure SKU is set to Standard for static
  #sku = "Basic" # Use this for dynamic. Apparantly being phased out in April 2025
}

resource "azurerm_network_interface" "etl" {
  name                = "etl-nic"
  location            = azurerm_resource_group.etl.location
  resource_group_name = azurerm_resource_group.etl.name

  ip_configuration {
    name                          = "internal"            # This can be anything that makes sense when viewed in the portal
    subnet_id                     = azurerm_subnet.etl.id # Connect this NIC to the subnet
    private_ip_address_allocation = "Dynamic"             # Private IP allocated out of subnet pool
    # private_ip_address_allocation = "Static"
    # private_ip_address            = "10.0.2.4" # If you want to specify a specific IP address
    public_ip_address_id = azurerm_public_ip.etl-ip.id # Leave this blank if you don't want a public IP
  }
}

# depends_on needed as terraform doesn't seem to know which order to delete these things
# and that's supposed to be its job
resource "azurerm_network_security_group" "etl" {
  depends_on          = [azurerm_network_interface.etl] # Make sure there is a NIC to attach this security group to as TF doesn't seem to be able to work it out
  name                = "etl-nsg"
  location            = azurerm_resource_group.etl.location
  resource_group_name = azurerm_resource_group.etl.name

  security_rule {
    name                       = "All_app_inbound_ports" # Anything you want
    priority                   = 1001                    # Lower numbers have higher priority
    direction                  = "Inbound"
    access                     = "Allow"             # Allow or Deny trafic
    protocol                   = "Tcp"               # e.g. tcp, udp or * for all protocols
    source_port_range          = "*"                 # Allow any source port number. Web clients use random port numbers
    destination_port_ranges    = ["22", "4000-4004"] # Restrict inbound traffic to target these ports. Sourde it the cient, sest is the server
    source_address_prefix      = "*"                 # Don't care who is connecting. Limit by providing address list or range
    destination_address_prefix = "*"                 # We don't care which IP address we route the traffic to in the network
  }
}

# We need to connect the security group to the network card
resource "azurerm_network_interface_security_group_association" "etl" {
  network_interface_id      = azurerm_network_interface.etl.id # Link by IDs
  network_security_group_id = azurerm_network_security_group.etl.id
}

# We now have the supporting infrastructure defines so define the VM
resource "azurerm_linux_virtual_machine" "etl-vm" {
  name                = "etl-vm1"                       # Call it what you want. This is how it will look in the portal
  resource_group_name = azurerm_resource_group.etl.name # Place in resource group
  location            = azurerm_resource_group.etl.location
  #size                = "Standard_B2s" # Free tier VM size - use B2s or similar if using a database
  #size           = "Standard_B2ats_v2"
  size           = "Standard_B1s"
  admin_username = "tony"

  network_interface_ids = [
    azurerm_network_interface.etl.id, # Connect the VM to its NIC. The NIC is already connected to the NSG 
  ]

  os_disk {
    caching              = "ReadWrite"    # Enable caching for performance
    storage_account_type = "Standard_LRS" # Standard locally redundant storage. Uses HDD AWS offers SSD on free tier. Replicates 3 x in data centre
    # Alternatives: StandardSSD_LRS, Premium_LRS, UltraSSD_LRS
    disk_size_gb = 64 # Size of the disk. 30GB is the minimum
  }

  source_image_reference {
    publisher = "Canonical"
    offer     = "0001-com-ubuntu-server-focal" # You need to look these things up
    sku       = "20_04-lts-gen2"               # OS version
    version   = "latest"                       # Latest 20.04 including minor version updates
  }

  admin_ssh_key {
    username = "tony"
    # Just copy public key from Azure ssh keys if you have one
    public_key = file(var.pub_key)
  }

  # Create a swap fie on the VM if it's low on memory and running a memory intensive app like MYSQL
  provisioner "remote-exec" {
    inline = [
      "sudo fallocate -l 2G /swapfile",                            # allocate a 2GB swap file
      "sudo chmod 600 /swapfile",                                  # set owner read/write
      "sudo mkswap /swapfile",                                     # mark the file as a swap file type
      "sudo swapon /swapfile",                                     # enable it for use now
      "echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab" # Append swapfile config to .fstab so persists after reboot
    ]
    connection {
      type        = "ssh"
      user        = "tony"
      private_key = file("c:\\key\\az.pem")
      # host        = azurerm_linux_virtual_machine.etl-vm.public_ip_address
      host = self.public_ip_address
    }
  }

  # Copy docker hub password file to vm to enable login without putting password in code
  provisioner "file" {
    source      = "c:/key/docker_hub_pass.txt"
    destination = "${local.dest_dir}/docker_hub_pass.txt"
    connection {
      type        = "ssh"
      user        = "tony"
      private_key = file("c:\\key\\az.pem")
      host        = self.public_ip_address
    }
  }
}

# Install docker on the created VM. Depends on the VM existing
# Copy the docker-az.sh script to the vm
# Login to the vm and run the script
resource "null_resource" "install_docker" {
  depends_on = [azurerm_linux_virtual_machine.etl-vm]

  # Copy docker install script to VM
  provisioner "file" {
    source      = "${var.one_drive_dir}/${var.docker_script_dir}/${var.docker_script_name}"
    destination = "${local.dest_dir}/${var.docker_script_name}"
    connection {
      type        = "ssh"
      user        = "tony"
      private_key = file("c:\\key\\az.pem")
      host        = azurerm_linux_virtual_machine.etl-vm.public_ip_address
    }
  }

  # Install docker
  provisioner "remote-exec" {
    inline = [
      "chmod +x ${local.dest_dir}/${var.docker_script_name}", # Make the script executable
      "sudo ${local.dest_dir}/${var.docker_script_name}"      # do it
    ]
    connection {
      type        = "ssh"
      user        = "tony"
      private_key = file("c:\\key\\az.pem")
      host        = azurerm_linux_virtual_machine.etl-vm.public_ip_address
    }
  }
}

# Once the VM is created and docker is installed, if the compose file has changed then copy it - otherwise use the one copied before
# The trigger enables this resource to run again if the file changes
# Add docker to the user group. This is handy if you need to login and run docker manually without having to use sudo all the time
# Get the password from the file and login to docker hub
# Run compose to pull images and start containers
# The env var is just an example of how to pass a variable env var into the compose script to be copied into env vars should you need to 
resource "null_resource" "start_containers" {
  depends_on = [azurerm_linux_virtual_machine.etl-vm, null_resource.install_docker]
  triggers = {
    always_run = "${timestamp()}" # always_run this null resource. Could check if image changed if you want to add code for that
  }

  provisioner "local-exec" {
    command     = <<-EOT
      docker compose -f "${var.compose_path}/compose.yaml" build
      docker push oldgitdocker/etl:latest
      docker push oldgitdocker/caller:latest
      docker push oldgitdocker/upload:latest
    EOT
    interpreter = ["powershell", "-Command"] # Pass the command to powershell
  }

  provisioner "file" {
    source      = "${var.compose_path}/compose.yaml"
    destination = "${local.dest_dir}/compose.yaml"
    connection {
      type        = "ssh"
      user        = "tony"
      private_key = file("c:\\key\\az.pem")
      host        = azurerm_linux_virtual_machine.etl-vm.public_ip_address
    }
  }

  provisioner "file" {
    source      = "${var.compose_path}/mongo.yaml"
    destination = "${local.dest_dir}/mongo.yaml"
    connection {
      type        = "ssh"
      user        = "tony"
      private_key = file("c:\\key\\az.pem")
      host        = azurerm_linux_virtual_machine.etl-vm.public_ip_address
    }
  }

  provisioner "file" {
    source      = "${var.compose_path}/.env"
    destination = "${local.dest_dir}/.env"
    connection {
      type        = "ssh"
      user        = "tony"
      private_key = file("c:\\key\\az.pem")
      host        = azurerm_linux_virtual_machine.etl-vm.public_ip_address
    }
  }


  # Note: adding docker to user group will generate a warning first time apply is run as docker isn't added until log out and in again 
  # so still using sudo here because it will add it which avoids the remote command line user keep using sudo
  # If apply is executed again, the warning isn't raised as this is effectively a new login
  # The conditional will start mysql or mongo based on the tfvars value
  # Or enter directly on the remote command line to choose one or the other
  provisioner "remote-exec" {
    inline = [
      "sudo usermod -aG docker $USER",                                                     # Add docker to my user group so I don't have to use sudo. Can't do this in shell script or it hangs as the shell is changed
      "cat ~/docker_hub_pass.txt | docker login --username oldgitdocker --password-stdin", # Pipe the password from the file into stdin to keep it sort of secret
      "sudo docker compose down",
      "${var.db_type == "mongo" ? "sudo DB_TYPE=mongo docker compose -f /home/tony/compose.yaml -f /home/tony/mongo.yaml up -d" : "sudo DB_TYPE=mysql docker compose -f /home/tony/compose.yaml up -d"}"
    ]
    connection {
      type        = "ssh"
      user        = "tony"
      private_key = file("c:\\key\\az.pem")
      host        = azurerm_linux_virtual_machine.etl-vm.public_ip_address
    }
  }
}

# Output useful info about the VM
output "vm-info" {
  value = {
    name       = azurerm_linux_virtual_machine.etl-vm.name
    vm_size    = azurerm_linux_virtual_machine.etl-vm.size
    private_ip = azurerm_network_interface.etl.private_ip_address
    public_ip  = azurerm_public_ip.etl-ip.ip_address
  }
}


