package uclan.myproject;

/**
 * Hello world!
 *
 */
public class App 
{   
    public String greet() {
        return "Hello CI/CD Demo";
    }
}


