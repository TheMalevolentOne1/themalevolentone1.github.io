//-----------------------------------------------------------------------------
// Stack class to be improved
//-----------------------------------------------------------------------------

#include <iostream>
#include <memory>
#include <string>

// Better than using using namespace std, just allow the names you use frequently
using std::cout;
using std::endl;

//-----------------------------------------------------------------------------


// Stack container class. Only manages strings at first but could use a template class to make this much better
class Stack
{
private:
	const int mCapacity; // Maximum size of stack, can be chosen on construction 
	int       mTop;      // Current index of top of stack - grows upwards to mCapacity

	std::unique_ptr<std::string[]> mData; // Store data in a unique_ptr array
	                                      // No need for a Stack destructor as this smart pointer will free memory
	                                      // automatically when it goes out of scope

public:
	// Constructor (pass max stack size)
	Stack(int capacity) : mCapacity(capacity) // Since mCapacity is const we can only put it in the initialiser list here, not in the code block below
	{
		mData = std::make_unique<std::string[]>(capacity); // Modern way to create a unique_ptr array (requires C++14 - default on latest Visual Studio 2022)
		mTop = 0;
	}

	// Pushes data onto the stack, increments top.
	// input: string newData. The data to be pushed onto the top of the stack.
	void push(std::string newData)
	{
		if (!isFull())
		{
			mData[mTop] = newData;
			++mTop;
		}
		else
		{
			cout << "stack full" << endl;
		}
	}

	// Pops data from the stack, decrements top. Does not return value popped, use top() for that
	void pop()
	{
		if (!isEmpty())
		{
			--mTop;
		}
	}


	// Returns data currently at the top of the stack
	std::string top() // Returns a copy of the top string, not the private mTop variable
	{
		if (!isEmpty())
		{
			return mData[mTop - 1];
		}
		// TODO: Compiler will warn that there is a missing return here ("not all control paths return a value"), but what to do when the stack is empty?!
	}


	// Returns true if the stack is full, false otherwise
	bool isFull()
	{
		if (mTop >= mCapacity)
		{
			return true;
		}
		return false;
	}

	// Returns true if the stack is empty, false otherwise
	bool isEmpty()
	{
		if (mTop <= 0)
		{
			return true;
		}
		return false;
	}


	// Displays contents of the stack starting from the bottom
	void display()
	{
		cout << "Stack contents: ";
		for (int i = 0; i < mTop; ++i)
		{
			cout << mData[i] << ", ";
		}
		cout << endl;
	}

};

//-----------------------------------------------------------------------------


int main()
{
	Stack myStack = Stack(5);

	// Push the rainbow colours onto the stack
	myStack.push("red");
	myStack.push("orange");
	myStack.push("yellow");
	myStack.push("green");
	myStack.push("blue");
	myStack.push("indigo");
	myStack.push("violet");

	// Show stack content
	myStack.display();
	cout << endl;

	// Pop and display all seven colours
	cout << "Pop " << myStack.top() << endl;
	myStack.pop();

	cout << "Pop " << myStack.top() << endl;
	myStack.pop();

	cout << "Pop " << myStack.top() << endl;
	myStack.pop();

	cout << "Pop " << myStack.top() << endl;
	myStack.pop();

	cout << "Pop " << myStack.top() << endl;
	myStack.pop();

	cout << "Pop " << myStack.top() << endl;
	myStack.pop();

	cout << "Pop " << myStack.top() << endl;
	myStack.pop();
}
