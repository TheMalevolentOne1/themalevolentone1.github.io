
class CValue
{
private:
	int* mpData;

public:
	CValue();
	void Set(int data);
	void Display();

	//~CValue();
};

