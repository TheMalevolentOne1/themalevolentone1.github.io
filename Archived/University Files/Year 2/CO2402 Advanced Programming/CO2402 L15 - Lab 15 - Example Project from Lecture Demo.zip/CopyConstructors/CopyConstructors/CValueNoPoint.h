#pragma once
class CValueNoPoint
{

private:
	int mpData;

public:
	CValueNoPoint();
	void Set(int data);
	void Display();

};

