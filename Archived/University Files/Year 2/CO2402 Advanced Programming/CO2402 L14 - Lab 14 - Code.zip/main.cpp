#include <iostream>
using namespace std;

#include "CTwoInts.h"

int main()
{
	CTwoInts a = CTwoInts();
	CTwoInts b = CTwoInts(3, 8);
	CTwoInts c = CTwoInts(2, 4);
	CTwoInts d = CTwoInts(5, 7);

	a = b;
	a.Display();
	cout << endl;

	b += c;
	a += b;
	a.Display();
	cout << endl;

	cout << a << b << c << d;
}
