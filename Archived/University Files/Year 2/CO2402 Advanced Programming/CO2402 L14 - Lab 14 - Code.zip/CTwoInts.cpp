#include <iostream>
using namespace std;

#include "CTwoInts.h"

void CTwoInts::Display()
{
	cout << "(" << mX << ", " << mY << ")";
}

CTwoInts CTwoInts::operator= (CTwoInts operand)
{
	mX = operand.mX;
	mY = operand.mY;
	return *this;
}

CTwoInts CTwoInts::operator+= (CTwoInts operand)
{
	mX += operand.mX;
	mY += operand.mY;
	return *this;
}

ostream& operator << (ostream& outputStream, const CTwoInts operand)
{
	cout << "(" << operand.mX << ", " << operand.mY << ") ";
	return outputStream;
}
