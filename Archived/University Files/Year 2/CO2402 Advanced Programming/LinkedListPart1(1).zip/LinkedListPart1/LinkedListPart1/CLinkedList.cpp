#include "CLinkedList.h"
//#include "CElement.h"
//#include <iostream>
//using namespace std;


CLinkedList::CLinkedList()
{
	mpHead = nullptr;
}

void CLinkedList::pushFront(int data){
	// allocate memory for new element
	CElement* pTemp = new CElement(data);
	pTemp->setNext(mpHead); // put temp in front of the old head of the list
	mpHead = pTemp; // head updated
}

void CLinkedList::popFront(){
	CElement* pTemp = mpHead; // store old head
	if (mpHead != nullptr){    // if list has at least one element
		mpHead = mpHead->getNext();
		delete pTemp;
	}
}

int CLinkedList::getFront(){
	if (mpHead != nullptr) // check list has at least one link
	{
		return mpHead->getData();
	}
	// only reached if the linked list is empty
	cout << "ERROR: list is empty" << endl;
	system("pause");
	exit(0);

}

void CLinkedList::printList(){
	CElement* pCurrent = mpHead; // can't use �mpHead' else 
	// we'd loose track of the
	// list start
	while (pCurrent != nullptr)  // 0 atend of the list.
	{
		cout << pCurrent->getData() << endl;
		pCurrent = pCurrent->getNext();
	}
	cout << endl;

}

CLinkedList::~CLinkedList(){
	CElement* pTemp = mpHead; // store old head
	while (mpHead != nullptr){    // if list has at least one element
		pTemp = mpHead;
		mpHead = mpHead->getNext();
		delete pTemp;
	}
}
