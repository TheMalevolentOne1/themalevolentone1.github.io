#pragma once
class CElement
{
public:
	CElement(int data);
	void setNext(CElement* next);
	CElement* getNext();
	int getData();
	~CElement();

private:
	int mData;
	CElement* mpNext;
};

