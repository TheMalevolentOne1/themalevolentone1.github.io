#include "CElement.h"

CElement::CElement(int data)
{
	mData = data;
	mpNext = nullptr;
}

void CElement::setNext(CElement* next)
{
	mpNext = next;
}

CElement* CElement::getNext()
{
	return mpNext;
}

int CElement::getData()
{
	return mData;
}

CElement::~CElement()
{
}
