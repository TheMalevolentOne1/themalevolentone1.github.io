#pragma once
//class CElement; //forward declaration

class CLinkedList
{
public:
	CLinkedList();
	~CLinkedList();
	void pushFront(int data);
	void popFront();
	int getFront();
	void printList();


private:
	CElement* mpHead;
};

