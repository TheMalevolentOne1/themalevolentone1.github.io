// LinkedListPart1.cpp : This file contains the 'main' function. Program execution begins and ends there.


#include <iostream>
#include "CLinkedList.h"

int main()
{
    std::cout << "Hello World!\n";
    CLinkedList* myList = new CLinkedList() ;
    myList->pushFront(2);
    myList->pushFront(4);
    myList->pushFront(6);
    myList->pushFront(8);

    myList->printList();
    delete myList;
}
