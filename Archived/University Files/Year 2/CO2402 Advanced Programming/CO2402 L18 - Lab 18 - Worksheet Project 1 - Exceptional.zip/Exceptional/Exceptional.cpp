#include <iostream>
#include <stdexcept>
#include <vector>


// Simple calculator class that demonstrates exception handling in exercise 1
class Calculator
{
public:
	int add(int a, int b) { return a + b; }

	int subtract(int a, int b) { return a - b; }

	int multiply(int a, int b) { return a * b; }

	int divide(int a, int b)
	{
		if (b == 0)
		{
			throw std::runtime_error("Division by zero");
		}
		return a / b;
	}
};



int main()
{
	Calculator calculator;

	std::cout << "Basic Exception Handling Exercise" << std::endl;
	std::cout << "=================================" << std::endl << std::endl;

	//------------------------------------------------------//
	// Exercise 1 -  Division by 0
	//
	// 1. What line throws the exception?
	// 2. What line catches it?
	// 3. Which lines were not executed due to the exception occurring?
	//
	// Note: the STL has some built in exceptions that use inheritance (use #include <exception>)
	//       std::exception is the base class
	//       std::runtime_error is one of the inherited classes
	// 4. Explain why the catch below works even though the thrown class was different
	//    - Would it be better to use std::runtime_error in the code below? Why or why not?
	// 
	// 4a. Advanced: See the list of STL exceptions here: https://en.cppreference.com/w/cpp/error/exception
	// 
	// 5. Add a square_root function to the class above and make it throw an exception if the
	//    value passed in is negative. In C++ use sqrt(x) for the square root
	// 
	// 6. Thoughtful: In the lecture we noted that exceptions should be typically be used for
	//                unexpected, externally created problems (e.g. hard disk error). This calculator
	//                example does not fit that suggestion - it uses exceptions to check parameters.
	//                What is your opinion? Is this approprate code?
	//                How could you write divide without exceptions? (there are simple and advanced answers)

	std::cout << "Example 1: Division operations" << std::endl << std::endl;

	int a, b, result;
	try
	{
		a = 80; b = 10;
		result = calculator.divide(a, b);
		std::cout << a << " / " << b << " = " << result << std::endl;

		a = 6;  b = 2;
		result = calculator.divide(a, b);
		std::cout << a << " / " << b << " = " << result << std::endl;

		a = 12; b = 0;
		result = calculator.divide(a, b);
		std::cout << a << " / " << b << " = " << result << std::endl;

		a = 16; b = 1;
		result = calculator.divide(a, b);
		std::cout << a << " / " << b << " = " << result << std::endl;
	}
	catch (const std::exception& e)
	{
		std::cout << "Error: " << e.what() << " when a = " << a << ", b = " << b << std::endl;
	}
	std::cout << std::endl << "=================================" << std::endl << std::endl;



	//------------------------------------------------------//
	// Exercise 2 - vector exception
	//
	// 1. Which specific exception was caught? What caused the exception? What was the value of e.what()?
	// 2. Fix the problem
	// 3. Research the at() method for vectors.
	//    - Slightly advanced: Replace at() with [] - what happens and why?
	//    - Advanced: At the top of Visual Studio, change "Debug" (next to x64) to "Release". Run it again - explain what happened?!
	//                Hint: Release mode aims for fastest code performance

	std::cout << "Example 2: Vector Access" << std::endl << std::endl;

	std::vector<int> numbers = { 3, 0, 12, 2 };
	try
	{
		for (int i = 0; i <= numbers.size(); i++)
		{
			std::cout << "numbers[" << i << "] = " << numbers.at(i) << std::endl;
		}
	}
	catch (const std::out_of_range& e)
	{
		std::cout << "Out of range error: " << e.what() << std::endl;
	}
	catch (const std::exception& e)
	{
		std::cout << "Other error: " << e.what() << std::endl;
	}
	std::cout << std::endl << "=================================" << std::endl << std::endl;



	//------------------------------------------------------//
	// Example 3: Nested try-catch blocks
	//
	// 1. Can you work out the flow of the program here? It throws two exceptions:
	//    - Which two lines throw the exceptions and which two lines caught them?
	// 2. Change the following line
	//        throw std::runtime_error("Exception from inner try block");
	//    to simply:
	//        throw -1;
	//    What happens? Can you catch the exception in the outer block with a catch all statement (see lecture slides)?

	std::cout << "Example 3: Nested Exceptions" << std::endl << std::endl;
	try
	{
		std::cout << "Outer try block" << std::endl;
		try
		{
			std::cout << "Inner try block" << std::endl;
			throw std::runtime_error("Exception from inner try block");
		}
		catch (int e)
		{
			std::cout << e << std::endl;
			throw;
		}
		catch (const std::runtime_error& e)
		{
			std::cout << "Inner catch: " << e.what() << std::endl;
			throw;
		}
	}
	catch (const std::domain_error& e)
	{
		std::cout << "Outer catch: " << e.what() << std::endl;
	}
	catch (const std::exception& e)
	{
		std::cout << "Outer catch: " << e.what() << std::endl;
	}
	std::cout << std::endl << "=================================" << std::endl << std::endl;
}