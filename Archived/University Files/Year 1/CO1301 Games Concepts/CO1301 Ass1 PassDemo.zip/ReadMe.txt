
Assignment1PassDemo.exe
=======================

This program demonstrates the minimum functionality required to pass 
CO1301 Assignment 1 2023-24.

If the program you submit for your assignment does exactly what this 
one does, and is coded nicely, you should expect to get a mark in the 3rd class range.

You should be able to run the demo by double-clicking the executable.

Be aware that this demo is a quick hack on my part, and will run faster or slower on different machines. See notes in the full assignment brief about playability and speed.

Excluding comments and blank lines, there are less than 150 lines of 
C++ code in this demo.

Note that the text which appears on the screen is not part of the demo...
it is just there to stop you demonstrating my work back to me in the lab!



